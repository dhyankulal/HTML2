# 🌿 Happy Journey Portal — Temple Run Green Radium Style

A two-page interactive "Happy Journey Wishes" website with full Temple Run jungle atmosphere.

---

## 📁 Folder Structure

```
journey-wish/
├── index.html       ← Page 1: Welcome / Input
├── journey.html     ← Page 2: Personalized Wish
├── style.css        ← All styles + animations
├── script.js        ← All JavaScript
├── README.md        ← This file
│
├── video/
│   └── journey.mp4  ← 🎬 Add your travel video here
│
├── audio/
│   └── music.mp3    ← 🎵 Add background music here
│
└── images/          ← Optional extra images
```

---

## 🚀 How to Use

1. **Open** `index.html` in any modern browser
2. **Enter** your name and destination
3. **Click** ⚡ START JOURNEY ⚡
4. Enjoy your personalized Temple Run jungle wish experience!

---

## 🎬 Adding Media

| File | Path | Effect |
|------|------|--------|
| Travel video | `video/journey.mp4` | Shows in the Journey Vision player |
| Background music | `audio/music.mp3` | Plays via 🎵 Play Music button |

Both are optional — the site works fully without them.

---

## ✨ Features

### Page 1 — Welcome Screen
- 🌿 Cinzel Decorative title with neon glow flicker
- 🏛️ Stone-carved input card with animated corners
- 🔥 Animated fire torches (top corners)
- 🏃 Running character on animated temple path
- 🌫️ Three-layer jungle fog
- ✨ Particle field (90 floating spores)
- 🍃 16 floating leaves with physics
- 📊 Temple Run progress meter
- 🖱️ Custom glowing cursor trail

### Page 2 — Journey Wish
- 💌 Personalized message with your name & destination glowing
- 🎊 Auto-confetti burst on entry
- 🎬 Video player (local mp4 → placeholder fallback)
- 🎵 Music player with play/pause/stop
- 🎉 Manual confetti button
- 🏠 Animated back-to-home transition
- 🔥 Four torches (all corners)
- 🌿 Jungle spine path down the center
- 📊 Infinite journey progress bar

### Everywhere
- ⚡ Wipe-transition between pages
- 🖱️ Neon green glowing cursor trail
- 🔊 Synthetic Web Audio button sounds
- 📱 Fully mobile responsive

---

## 🎨 Design System

| Token | Value | Use |
|-------|-------|-----|
| `--g` | `#39FF14` | Neon green |
| `--gold` | `#FFD700` | Wish highlights |
| `--fire` | `#ff6a00` | Torch flames |
| `--bg` | `#010801` | Deep jungle black |
| Font: Title | Cinzel Decorative | Headers |
| Font: Game | Orbitron | Labels/HUD |
| Font: Body | Rajdhani | Text |
