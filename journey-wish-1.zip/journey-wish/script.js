/* ═══════════════════════════════════════════════════════════════
   HAPPY JOURNEY PORTAL  ·  script.js
   Temple Run Green Radium Style
   ═══════════════════════════════════════════════════════════════ */

'use strict';

/* ─────────────────────────────────────────
   PAGE DETECTION
───────────────────────────────────────── */
const PAGE = {
  isIndex:   document.body.id === 'page-index',
  isJourney: document.body.id === 'page-journey',
};

/* ─────────────────────────────────────────
   CUSTOM CURSOR
───────────────────────────────────────── */
(function initCursor() {
  const TRAIL_LEN = 10;
  const dots = [];
  for (let i = 0; i < TRAIL_LEN; i++) {
    const d = document.createElement('div');
    const r = (TRAIL_LEN - i) * 3.2;
    d.style.cssText = `
      position:fixed;pointer-events:none;z-index:99999;
      width:${r}px;height:${r}px;border-radius:50%;
      background:radial-gradient(circle,
        rgba(57,255,20,${0.7 - i * 0.06}) 0%,transparent 70%);
      transform:translate(-50%,-50%);
      transition:left ${i * 22}ms linear,top ${i * 22}ms linear;
      will-change:left,top;
    `;
    document.body.appendChild(d);
    dots.push(d);
  }
  document.addEventListener('mousemove', e => {
    dots.forEach(d => {
      d.style.left = e.clientX + 'px';
      d.style.top  = e.clientY + 'px';
    });
  });
})();

/* ─────────────────────────────────────────
   PARTICLE BACKGROUND
───────────────────────────────────────── */
(function initParticles() {
  const canvas = document.getElementById('bgCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, pts = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  function mkPt() {
    return {
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 2.4 + 0.4,
      dx: (Math.random() - 0.5) * 0.35,
      dy: -(Math.random() * 0.7 + 0.15),
      a: Math.random() * 0.6 + 0.1,
      life: 0,
      max: Math.random() * 180 + 90
    };
  }

  for (let i = 0; i < 90; i++) {
    const p = mkPt();
    p.life = Math.random() * p.max; // stagger
    pts.push(p);
  }

  function loop() {
    ctx.clearRect(0, 0, W, H);
    pts.forEach((p, i) => {
      p.x += p.dx; p.y += p.dy; p.life++;
      const f = p.life < 25 ? p.life / 25 :
                p.life > p.max - 25 ? (p.max - p.life) / 25 : 1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(57,255,20,${p.a * f})`;
      ctx.shadowBlur = 8; ctx.shadowColor = '#39FF14';
      ctx.fill(); ctx.shadowBlur = 0;

      if (p.life >= p.max || p.y < -8 || p.x < -8 || p.x > W + 8) {
        pts[i] = mkPt();
        pts[i].y = H + 4;
      }
    });
    requestAnimationFrame(loop);
  }
  loop();
})();

/* ─────────────────────────────────────────
   FLOATING LEAVES
───────────────────────────────────────── */
(function initLeaves() {
  const wrap = document.getElementById('leafBurst');
  if (!wrap) return;
  const emojis = ['🌿','🍃','🌱','☘️','🍀','🌾'];
  const n = window.innerWidth < 480 ? 8 : 16;
  for (let i = 0; i < n; i++) {
    const el = document.createElement('div');
    el.className = 'leaf';
    el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    const dur = (Math.random() * 8 + 8).toFixed(1);
    const del = -(Math.random() * 12).toFixed(1);
    el.style.cssText = `
      left:${Math.random() * 100}%;
      font-size:${Math.random() * 10 + 13}px;
      --dur:${dur}s; animation-delay:${del}s;
    `;
    wrap.appendChild(el);
  }
})();

/* ─────────────────────────────────────────
   RUNNER TRACK TILES
───────────────────────────────────────── */
(function initTrackTiles() {
  const wrap = document.getElementById('trackTiles');
  if (!wrap) return;
  for (let i = 0; i < 26; i++) {
    const t = document.createElement('div');
    t.className = 'track-tile';
    wrap.appendChild(t);
  }
})();

/* ─────────────────────────────────────────
   INDEX: PROGRESS METER
───────────────────────────────────────── */
if (PAGE.isIndex) {
  let val = 0;
  const fill  = document.getElementById('hudFill');
  const score = document.getElementById('hudScore');
  const iv = setInterval(() => {
    val += Math.random() * 1.8;
    if (val > 100) val = 100;
    if (fill)  fill.style.width = val + '%';
    if (score) score.textContent = Math.round(val * 52) + ' m';
    if (val >= 100) clearInterval(iv);
  }, 100);
}

/* ─────────────────────────────────────────
   INDEX: INPUT + NAVIGATION
───────────────────────────────────────── */
function handleStart() {
  const nameEl  = document.getElementById('inp-name');
  const destEl  = document.getElementById('inp-dest');
  const errEl   = document.getElementById('errMsg');
  const name    = (nameEl?.value || '').trim();
  const dest    = (destEl?.value || '').trim();

  if (!name || !dest) {
    errEl?.classList.add('show');
    if (!name) { nameEl.style.borderColor = 'var(--red)'; nameEl.focus(); }
    if (!dest)   destEl.style.borderColor = 'var(--red)';
    setTimeout(() => {
      errEl?.classList.remove('show');
      if (nameEl) nameEl.style.borderColor = '';
      if (destEl) destEl.style.borderColor = '';
    }, 3200);
    playBeep('error');
    return;
  }

  playBeep('success');
  localStorage.setItem('journey_name', name);
  localStorage.setItem('journey_dest', dest);

  // Animate button spark
  spawnBtnParticles();

  setTimeout(() => {
    const ov = document.getElementById('wipeOverlay');
    if (ov) {
      ov.classList.add('wipe-go');
      setTimeout(() => { window.location.href = 'journey.html'; }, 560);
    } else {
      window.location.href = 'journey.html';
    }
  }, 350);
}

function spawnBtnParticles() {
  const wrap = document.getElementById('sbParticles');
  if (!wrap) return;
  for (let i = 0; i < 18; i++) {
    const p = document.createElement('span');
    const angle = Math.random() * 360;
    const dist  = Math.random() * 60 + 20;
    p.style.cssText = `
      position:absolute;left:50%;top:50%;
      width:5px;height:5px;border-radius:50%;
      background:var(--g);
      box-shadow:0 0 8px var(--glow);
      transform:translate(-50%,-50%);
      animation:btnPart .6s ease-out forwards;
      --a:${angle}deg;--d:${dist}px;
    `;
    wrap.appendChild(p);
    setTimeout(() => p.remove(), 650);
  }
}

/* Inject particle keyframe once */
(function() {
  const s = document.createElement('style');
  s.textContent = `@keyframes btnPart{
    0%  {transform:translate(-50%,-50%) rotate(var(--a)) translateY(0);opacity:1}
    100%{transform:translate(-50%,-50%) rotate(var(--a)) translateY(calc(-1*var(--d)));opacity:0}
  }`;
  document.head.appendChild(s);
})();

// Enter key support
document.addEventListener('DOMContentLoaded', () => {
  ['inp-name','inp-dest'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('keydown', e => e.key === 'Enter' && handleStart());
    if (el) el.addEventListener('input',   () => el.style.borderColor = '');
  });
});

/* ─────────────────────────────────────────
   JOURNEY PAGE  ·  JourneyApp namespace
───────────────────────────────────────── */
const JourneyApp = (() => {
  let musicPlaying = false;
  const audio = document.getElementById('bgAudio');

  /* INIT ------------------------------------------------ */
  function init() {
    // Wipe out transition
    const ov = document.getElementById('wipeOverlay');
    if (ov) {
      ov.classList.add('wipe-back');
      setTimeout(() => ov.classList.remove('wipe-back'), 700);
    }

    // Load data
    const name = localStorage.getItem('journey_name') || 'Brave Adventurer';
    const dest = localStorage.getItem('journey_dest') || 'Your Destination';

    setText('wsName', name);
    setText('wsDest', dest);
    setText('shName', name);
    setText('shDest', dest);

    // Video
    initVideo();

    // Welcome confetti burst
    setTimeout(confetti, 700);
  }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  /* VIDEO ------------------------------------------------ */
  function initVideo() {
    const inner = document.getElementById('vsInner');
    if (!inner) return;

    // Try local video first
    const vid = document.createElement('video');
    vid.controls = true;
    vid.style.cssText = 'width:100%;height:100%;border-radius:12px;display:none';
    const src = document.createElement('source');
    src.src  = 'video/journey.mp4';
    src.type = 'video/mp4';
    vid.appendChild(src);

    vid.addEventListener('canplay', () => {
      inner.innerHTML = '';
      inner.appendChild(vid);
      vid.style.display = 'block';
    });

    vid.addEventListener('error', () => {
      showVideoPlaceholder(inner);
    });

    inner.appendChild(vid);
    vid.load();

    // Fallback after 1.5s
    setTimeout(() => {
      if (vid.readyState < 2) showVideoPlaceholder(inner);
    }, 1500);
  }

  function showVideoPlaceholder(inner) {
    inner.innerHTML = `
      <div class="vs-placeholder">
        <div class="vsp-icon">🎬</div>
        <p>Place <strong>journey.mp4</strong> in the <code>/video/</code> folder<br>
           and <strong>music.mp3</strong> in <code>/audio/</code> to enable media.</p>
        <p style="margin-top:8px;font-size:12px;opacity:.5">
          Or open in a live server environment for YouTube embed support.
        </p>
      </div>`;
  }

  /* MUSIC ------------------------------------------------ */
  function toggleMusic() {
    if (!audio) { alert('Add music.mp3 to /audio/ folder!'); return; }
    if (musicPlaying) {
      audio.pause();
      musicPlaying = false;
      updateMusicBtn(false);
    } else {
      audio.play()
        .then(() => { musicPlaying = true; updateMusicBtn(true); })
        .catch(() => alert('🎵 Add music.mp3 to the /audio/ folder!'));
    }
    playBeep('click');
  }

  function stopMusic() {
    if (!audio) return;
    audio.pause();
    audio.currentTime = 0;
    musicPlaying = false;
    updateMusicBtn(false);
    playBeep('click');
  }

  function updateMusicBtn(playing) {
    const btn  = document.getElementById('btnMusic');
    const icon = btn?.querySelector('.cpb-icon');
    const txt  = btn?.querySelector('.cpb-txt');
    if (!btn) return;
    if (playing) {
      btn.classList.add('is-playing');
      if (icon) icon.textContent = '▶️';
      if (txt)  txt.textContent  = 'Pause Music';
    } else {
      btn.classList.remove('is-playing');
      if (icon) icon.textContent = '🎵';
      if (txt)  txt.textContent  = 'Play Music';
    }
  }

  /* CONFETTI --------------------------------------------- */
  function confetti(auto = false) {
    const canvas = document.getElementById('confettiCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;

    const COLORS = [
      '#39FF14','#00e60d','#ffff00','#ff6a00',
      '#ff00ff','#00ccff','#ffffff','#ffd700','#ff3c3c'
    ];

    const N = auto ? 130 : 200;
    const pieces = Array.from({length: N}, () => ({
      x:   Math.random() * canvas.width,
      y:   Math.random() * canvas.height * 0.45 - 10,
      r:   Math.random() * 8 + 3,
      c:   COLORS[Math.floor(Math.random() * COLORS.length)],
      dx:  (Math.random() - 0.5) * 6.5,
      dy:  Math.random() * 3.5 + 1.5,
      rot: Math.random() * Math.PI * 2,
      dRot:(Math.random() - 0.5) * 0.18,
      shape: Math.random() < 0.5 ? 'rect' : 'circ',
      life: 0,
      max:  Math.random() * 110 + 80
    }));

    let raf;
    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = false;
      pieces.forEach(p => {
        p.x += p.dx; p.y += p.dy + (p.life * 0.04);
        p.rot += p.dRot; p.life++;
        const f = p.life > p.max - 30 ? (p.max - p.life) / 30 : 1;
        if (f > 0) alive = true;

        ctx.save();
        ctx.globalAlpha = f;
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.c;
        ctx.shadowBlur = 6; ctx.shadowColor = p.c;

        if (p.shape === 'circ') {
          ctx.beginPath();
          ctx.arc(0, 0, p.r, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillRect(-p.r / 2, -p.r, p.r, p.r * 2.2);
        }
        ctx.restore();
      });
      if (alive) raf = requestAnimationFrame(draw);
      else { cancelAnimationFrame(raf); ctx.clearRect(0,0,canvas.width,canvas.height); }
    }
    cancelAnimationFrame(raf);
    draw();
    if (!auto) playBeep('celebrate');
  }

  /* GO HOME --------------------------------------------- */
  function goHome() {
    playBeep('click');
    const ov = document.getElementById('wipeOverlay');
    if (ov) {
      ov.classList.add('wipe-go');
      setTimeout(() => { window.location.href = 'index.html'; }, 560);
    } else {
      window.location.href = 'index.html';
    }
  }

  /* Auto-init ------------------------------------------- */
  if (PAGE.isJourney) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  }

  // Confetti canvas resize
  window.addEventListener('resize', () => {
    const cc = document.getElementById('confettiCanvas');
    if (cc) { cc.width = window.innerWidth; cc.height = window.innerHeight; }
  });

  return { toggleMusic, stopMusic, confetti: () => confetti(false), goHome };
})();

/* ─────────────────────────────────────────
   SYNTHETIC SOUND FX  (Web Audio API)
───────────────────────────────────────── */
function playBeep(type = 'click') {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx  = new AC();
    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const presets = {
      click:    { f: 520, fEnd: 280, dur: .12, vol: .15 },
      error:    { f: 220, fEnd: 110, dur: .25, vol: .18 },
      success:  { f: 440, fEnd: 880, dur: .30, vol: .18 },
      celebrate:{ f: 660, fEnd: 1320,dur: .35, vol: .2  },
    };
    const p = presets[type] || presets.click;

    osc.frequency.setValueAtTime(p.f, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(p.fEnd, ctx.currentTime + p.dur);
    gain.gain.setValueAtTime(p.vol, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + p.dur);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + p.dur + 0.01);
  } catch (_) {}
}

/* ─────────────────────────────────────────
   ATTACH CLICK BEEPS TO BUTTONS
───────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.start-btn, .cp-btn').forEach(btn => {
    btn.addEventListener('click', () => playBeep('click'));
  });
});
